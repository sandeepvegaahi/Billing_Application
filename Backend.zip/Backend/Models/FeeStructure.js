// models/FeeStructure.js
const mongoose = require("mongoose");

const feeStructureSchema = new mongoose.Schema({
  category: { type: String, required: true, trim: true },
  amount: { type: Number, required: true },
  year: { type: String, required: true }, // e.g., "Year 1"
  billPrefix: { type: String, required: true }, // TF, BF, etc.
  currentBillNumber: { type: Number, required: true }, // numeric part only
}, { timestamps: true });

module.exports = mongoose.model("FeeStructure", feeStructureSchema);
