// routes/feeStructureRoutes.js
const express = require("express");
const router = express.Router();
const {
  createFee,
  getFees,
  updateFee,
  deleteFee,
  generateBill
} = require("../controllers/feeStructureController");

// CRUD for fee structure
router.post("/", createFee);          // Create fee
router.get("/", getFees);             // Get all fees
router.put("/:id", updateFee);        // Update fee
router.delete("/:id", deleteFee);     // Delete fee

// Generate next bill number
router.post("/generate-bill", generateBill);

module.exports = router;
