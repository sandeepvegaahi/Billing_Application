// controllers/feeStructureController.js
const FeeStructure = require("../Models/FeeStructure");

/* ================= CREATE FEE STRUCTURE ================= */
exports.createFee = async (req, res) => {
  try {
    const { category, amount, year, billPrefix, currentBillNumber } = req.body;

    if (!category || !amount || !year || !billPrefix || !currentBillNumber) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    const fee = await FeeStructure.create({
      category,
      amount,
      year,
      billPrefix,
      currentBillNumber,
    });

    res.status(201).json({ success: true, message: "Fee structure created", data: fee });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/* ================= GET ALL FEES ================= */
exports.getFees = async (req, res) => {
  try {
    const fees = await FeeStructure.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: fees });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/* ================= UPDATE FEE ================= */
exports.updateFee = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedFee = await FeeStructure.findByIdAndUpdate(id, req.body, { new: true });

    if (!updatedFee) return res.status(404).json({ success: false, message: "Fee not found" });

    res.status(200).json({ success: true, message: "Fee updated", data: updatedFee });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/* ================= DELETE FEE ================= */
exports.deleteFee = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedFee = await FeeStructure.findByIdAndDelete(id);

    if (!deletedFee) return res.status(404).json({ success: false, message: "Fee not found" });

    res.status(200).json({ success: true, message: "Fee deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/* ================= GENERATE NEXT BILL NUMBER ================= */
exports.generateBill = async (req, res) => {
  try {
    const { category } = req.body; // e.g., "Tuition"
    const fee = await FeeStructure.findOne({ category });

    if (!fee) return res.status(404).json({ success: false, message: "Fee category not found" });

    // Increment number
    fee.currentBillNumber += 1;
    await fee.save();

    // Combine prefix + number
    const newBillNo = fee.billPrefix + fee.currentBillNumber;

    res.status(200).json({ success: true, billNumber: newBillNo });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
