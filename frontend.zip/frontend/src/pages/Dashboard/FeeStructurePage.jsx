import React, { useEffect, useState } from "react";
import api from "../../api/api";
import { Card, Button, Row, Col, Form, Table } from "react-bootstrap";

const FeeStructurePage = () => {
  const [fees, setFees] = useState([]);
  const nextbillno = currentBillNumber + 1;
  const [newFee, setNewFee] = useState({
    category: "",
    amount: "",
    year: "",
    billPrefix: "",
    currentBillNumber: "",
  });
  const [nextBill, setNextBill] = useState("");

  // Fetch all fees
  const fetchFees = async () => {
    try {
      const res = await api.get("/fee-structure");
      setFees(res.data.data);
    } catch (err) {
      console.error("Error fetching fees:", err);
    }
  };

  useEffect(() => {
    fetchFees();
  }, []);

  const handleChange = (e) => {
    setNewFee({ ...newFee, [e.target.name]: e.target.value });
  };

  const handleAddFee = async (e) => {
    e.preventDefault();
    try {
      await api.post("/fee-structure", {
        ...newFee,
        amount: Number(newFee.amount),
        currentBillNumber: Number(newFee.currentBillNumber),
      });
      setNewFee({
        category: "",
        amount: "",
        year: "",
        billPrefix: "",
        currentBillNumber: "",
      });
      fetchFees();
    } catch (err) {
      console.error("Error adding fee:", err);
    }
  };

  const handleDelete = async (id) => {
    try {
      await api.delete(`/fee-structure/${id}`);
      fetchFees();
    } catch (err) {
      console.error("Error deleting fee:", err);
    }
  };

  const handleGenerateBill = async (category) => {
    try {
      const res = await api.post("/fee-structure/generate-bill", { category });
      setNextBill(`Next bill for ${category}: ${res.data.billNumber}`);
      fetchFees();
    } catch (err) {
      console.error("Error generating bill:", err);
    }
  };

  return (
    <div>
      <h2 className="mb-4">Fee Structure Management</h2>

      {/* Add Fee Card */}
      <Card className="mb-4 shadow-sm">
        <Card.Body>
          <Card.Title>Add New Fee Category</Card.Title>
          <Form onSubmit={handleAddFee}>
            <Row className="mb-2">
              <Col>
                <Form.Control
                  type="text"
                  placeholder="Category"
                  name="category"
                  value={newFee.category}
                  onChange={handleChange}
                  required
                />
              </Col>
              <Col>
                <Form.Control
                  type="number"
                  placeholder="Amount"
                  name="amount"
                  value={newFee.amount}
                  onChange={handleChange}
                  required
                />
              </Col>
              <Col>
                <Form.Control
                  type="text"
                  placeholder="Year"
                  name="year"
                  value={newFee.year}
                  onChange={handleChange}
                  required
                />
              </Col>
            </Row>
            <Row className="mb-2">
              <Col>
                <Form.Control
                  type="text"
                  placeholder="Bill Prefix"
                  name="billPrefix"
                  value={newFee.billPrefix}
                  onChange={handleChange}
                  required
                />
              </Col>
              <Col>
                <Form.Control
                  type="number"
                  placeholder="Current Bill No"
                  name="currentBillNumber"
                  value={newFee.currentBillNumber}
                  onChange={handleChange}
                  required
                />
              </Col>
              <Col>
                <Button type="submit" variant="primary">
                  Add Fee
                </Button>
              </Col>
            </Row>
          </Form>
        </Card.Body>
      </Card>

      {/* Fee Cards */}
      <Row className="g-3">
        {fees.map((fee) => (
          <Col md={4} key={fee._id}>
            <Card className="shadow-sm">
              <Card.Body>
                <Card.Title>{fee.category}</Card.Title>
                <Card.Text>
                  <strong>Amount:</strong> ₹{fee.amount} <br />
                  <strong>Year:</strong> {fee.year} <br />
                  <strong>Bill Prefix:</strong> {fee.billPrefix} <br />
                  <strong>Current Bill No:</strong> {fee.currentBillNumber}
                </Card.Text>
                <Button
                  variant="success"
                  size="sm"
                  className="me-2"
                  onClick={() => handleGenerateBill(fee.category)}
                >
                  Generate Bill
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => handleDelete(fee._id)}
                >
                  Delete
                </Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      {/* Next Bill Info */}
      {nextBill && (
        <Card className="mt-4 shadow-sm">
          <Card.Body>{nextBill}</Card.Body>
        </Card>
      )}
    </div>
  );
};

export default FeeStructurePage;
